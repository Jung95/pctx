# Original reproduction

Public repository: https://github.com/Jung95/pctx
Source baseline: 99462daf0c360f84c56fee7e76eadaaecb21db37
Test source: https://github.com/Jung95/pctx/blob/99462daf0c360f84c56fee7e76eadaaecb21db37/tests/project_deadline.rs
Supervisor: https://github.com/Jung95/pctx/blob/99462daf0c360f84c56fee7e76eadaaecb21db37/src/query_process.rs

From a normal checkout with Rust and locked dependencies:

```sh
cargo test --locked --test project_deadline concurrent_query_startup_preserves_group_streams_and_original_one_second_budget -- --exact --nocapture --test-threads=1
```

Instruction only; not a new run or standalone OS-only reproducer. Eight workers each create one script before their16-execution loop. Three failures abort their worker loops; do not claim all128 outcomes ran. Preserve deadline, concurrency, fixture first-launch state, environment, direct executable, PGID, streams and cancellation. Do not run distribution checks or dummy scripts against the fixture beforehand.
